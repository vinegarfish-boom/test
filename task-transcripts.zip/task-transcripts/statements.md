# 六道自进化题目原文

[返回逐题目录](<C:/Users/Administrator/Downloads/task-analysis-iter3.81-20261008/task-transcripts/index.md>)

## S1

来源：A R21、B R12，A 与 B 正文逐字一致。

````markdown
# 自进化任务 S-1：编写任务处理脚本

> 沙盒内：python: 2.7.9，python3: 3.11.10

## 任务背景

你是人类抵抗军的自动化脚本工程师。机器人大战爆发后，情报数据的预处理全靠人工，任务官希望你编写一个 Python 脚本，把一份任务清单（`work/input_s1.json`）处理成统计报告，并允许你用公开样例自测。

## 任务要求

1. 进入工作区：`cd /tmp/selfEvolutionTask/1-fixed-step/4-script-dev`
2. 查看公开样例 `test_cases/s1_cases.json`（5 组"输入→期望输出"配对，**规则需要你从样例中归纳**）
3. 编写脚本（建议保存为 `solve.py`），处理 `work/input_s1.json`，把结果写入 `work/result_s1.json`
4. 运行 `./check_s1` 验证结果
5. 当 `./check_s1` 输出 `TOKEN: xxx` 时，任务完成

**输入数据格式**（`work/input_s1.json` 为记录数组，每条记录含）：

```json
{"id": 1, "priority": 42, "disabled": false, "category": "A", "amount": 100}
```

- `priority`：任务优先级（数字越大越优先）
- `disabled`：是否停用
- `category`：任务类别
- `amount`：任务量

## 提交规则

- 任务完成以 `./check_s1` 输出 `TOKEN: xxx` 为准，通过`submitAnswer`来提交答案，形式：

  ```
  {"token": "xxx"}
  ```

- 你可以反复运行 `./check_s1` 查看进度，直到全部通过

## 提示

- **先看公开样例再动手**：样例的"输入→期望输出"已展示完整规则（过滤条件、排序方式、分组与合并方式）
- 公开样例可以通过所有规则细节，隐藏样例只是数据更大，规则完全相同
- 建议把处理逻辑封装为 `transform(records)` 函数，后续可能还有类似任务
- 产物文件必须是合法 JSON，注意数字与字符串类型

````

## S2

来源：A R102、B R109，A 与 B 正文逐字一致。

````markdown
# 自进化任务 S-2：任务处理脚本——字段换名

> 沙盒内：python: 2.7.9，python3: 3.11.10

## 任务背景

同一套预处理流水线需要处理另一类任务清单。**数据格式与上一题相同，仅字段名和分组名变化**。请复用你的脚本（或做最小修改），处理 `work/input_s2.json`。

## 任务要求

1. 查看公开样例 `test_cases/s2_cases.json`（5 组"输入→期望输出"配对，规则需要从样例中归纳）
2. 处理 `work/input_s2.json`，把结果写入 `work/result_s2.json`
3. 运行 `./check_s2` 验证结果
4. 当 `./check_s2` 输出 `TOKEN: xxx` 时，任务完成

**输入数据格式**（`work/input_s2.json` 为记录数组，每条记录含）：

```json
{"id": 1, "deadline": "2024-03-05", "archived": false, "group": "g1", "total": 100}
```

- `deadline`：截止日期（字符串，可直接按字典序比较）
- `archived`：是否归档
- `group`：分组名
- `total`：任务量

## 提交规则

- 任务完成以 `./check_s2` 输出 `TOKEN: xxx` 为准，通过`submitAnswer`来提交答案，形式：

  ```
  {"token": "xxx"}
  ```

## 提示

- 规则与上一题**结构相同**（过滤→排序→分组求和），只是字段名换了，输出结构与上一题相同
- 直接复用你上一题的 `transform(records)` 函数，把字段名参数化即可

````

## S3

来源：A R160、B R152，A 与 B 正文逐字一致。

````markdown
# 自进化任务 S-3：任务处理脚本——分组明细输出

> 沙盒内：python: 2.7.9，python3: 3.11.10

## 任务背景

流水线的输出格式需要升级：报告不仅要分组合计，还要附上组内明细。**数据格式与 S-1 完全相同**（priority/disabled/category/amount 字段），请复用你的脚本，处理 `work/input_s3.json`。

## 任务要求

1. 查看公开样例 `test_cases/s3_cases.json`（5 组"输入→期望输出"配对，规则需要从样例中归纳）
2. 处理 `work/input_s3.json`，把结果写入 `work/result_s3.json`
3. 运行 `./check_s3` 验证结果
4. 当 `./check_s3` 输出 `TOKEN: xxx` 时，任务完成

**输入数据格式**（`work/input_s3.json` 为记录数组，字段与 S-1 相同）：

```json
{"id": 1, "priority": 42, "disabled": false, "category": "A", "amount": 100}
```

## 提交规则

- 任务完成以 `./check_s3` 输出 `TOKEN: xxx` 为准，通过`submitAnswer`来提交答案，形式：

  ```
  {"token": "xxx"}
  ```

## 提示

- 本题数据字段与 S-1 相同（直接复用 S-1 的过滤+排序逻辑），但**输出结构不同**（分组嵌套明细）且**多了一条过滤条件**——看样例确认
- 组内明细条目的字段与输入不同，只保留 `id` 与 `amount`
- 建议把输出层的"嵌套格式"单独封装，与过滤/排序逻辑解耦

````

## L1

来源：A R11、B R27，A 与 B 正文逐字一致。

````markdown
# 自进化任务 L-1：统计营地三系统故障态势

> 沙盒内：python: 2.7.9，python3: 3.11.10

## 任务背景

你是人类抵抗军的网络运维分析师。机器人大战爆发后，营地三套关键系统（视频监控 / 通信网关 / 后勤调度）的日志存放在本任务文件所在目录的 `day1/` 中（`/tmp/selfEvolutionTask/4-data-analysis/1-log-analysis/day1/`）。三套系统由不同厂商维护，**日志格式各不相同**，且日志中既有正常运行记录也有故障记录。任务官需要你统计今晨以来的故障态势。

## 任务要求

读取 `day1/` 下的 3 个日志文件（`monitor_*.log`、`gateway_*.log`、`logistics_*.log`），识别故障信号并统计：

```json
{
  "errors": {
    "monitor": <视频监控系统故障条数>,
    "gateway": <通信网关系统故障条数>,
    "logistics": <后勤调度系统故障条数>
  },
  "peak_hour": "<全局故障最多的1小时窗口，如'14时'>",
  "peak_count": <该小时内的故障总条数>
}
```

**故障信号定义**（各系统自己的"异常标记"，正常运行记录不算）：

- 视频监控日志（`[时间] 级别 module=模块 src=IP msg=消息`）：`ERROR` 级别
- 通信网关日志（`IP - - [日期] "GET 路径 HTTP/1.1" 状态码`）：状态码 `>= 500`
- 后勤调度日志（`月 日 时间 主机 daemon: 信号 详情`）：以 `OOM-killer` / `disk-full` / `net-down` 开头的行

`peak_hour` 与 `peak_count`：把三份日志中**所有故障**按小时聚合，取故障条数最多的小时（并列时取较早的小时）。

## 提交形式

- 以字符串的形式提交给`submitAnswer`，例如：

```json
{"errors":{"monitor":0,"gateway":0,"logistics":0},"peak_hour":"14时","peak_count":0}
```

- 提交答案为数字/字符串敏感型，不能将数字0写成"0"，否则算错

## 提示

- 三份日志的格式互不相同，请先用 `head` 或 `cat` 观察每份日志的真实格式再写解析
- 建议先写出一个 `parse_line(line)` 解析函数，把每行归一化为（系统、时间、是否故障），再聚合
- 解析逻辑整理为可复用的脚本，后续还有类似任务

````

## L2

来源：A R115、B R124，A 与 B 正文逐字一致。

````markdown
# 自进化任务 L-2：故障类型分布与高频模块分析

> 沙盒内：python: 2.7.9，python3: 3.11.10

## 任务背景

环境评估报告需要补充六月的故障画像。请使用与上一题**完全相同的日志格式和解析方法**（你的解析脚本无需任何修改），处理新一批日志：本任务文件所在目录的 `day2/`（`/tmp/selfEvolutionTask/4-data-analysis/1-log-analysis/day2/`）。

## 任务要求

读取 `day2/` 下的 3 个日志文件，统计故障按类型的分布：

```json
{
  "total_failures": <故障总条数>,
  "by_type": {
    "error": <视频监控 ERROR 条数>,
    "http500": <通信网关 5xx 条数>,
    "oom": <后勤调度 OOM-killer/disk-full/net-down 条数>
  },
  "top_module": "<故障消息中出现次数最多的模块名>",
  "top_module_count": <该模块的故障条数>
}
```

- `top_module` 统计范围：视频监控日志中 `module=` 后的模块名（通信网关与后勤日志没有模块字段，不参与此项统计）
- 故障信号定义与上一题相同

## 提交形式

- 以字符串的形式提交给`submitAnswer`，例如：

```json
{"total_failures":0,"by_type":{"error":0,"http500":0,"oom":0},"top_module":"a","top_module_count":0}
```

- 提交答案为数字/字符串敏感型，不能将数字0写成"0"，否则算错

## 提示

- 日志格式与上一题完全相同，直接复用上一题的解析脚本即可
- 本题只需改聚合逻辑（按类型/按模块），解析部分一行都不用改

````

## L3

来源：A R231、B R172，A 与 B 正文逐字一致。

````markdown
# 自进化任务 L-3：故障事件时长分析

> 沙盒内：python: 2.7.9，python3: 3.11.10

## 任务背景

评估报告的最后一个维度：一次"故障事件"会持续多久。请使用与上一题**完全相同的日志格式和解析方法**，处理 `day3/`（`/tmp/selfEvolutionTask/4-data-analysis/1-log-analysis/day3/`）的新一批日志。

## 任务要求

读取 `day3/` 下的 3 个日志文件，按以下规则统计故障**事件**：

**事件定义**：同一系统内，相邻两条故障记录的时间差不超过 5 分钟（含 5 分钟），视为同一次故障事件的延续；超过 5 分钟视为新事件。每个事件从该系统的首条故障到末条故障连续统计。

```json
{
  "total_events": <故障事件总数>,
  "avg_duration_minutes": <所有事件的时长平均值（四舍五入到整数分钟）>,
  "longest_event": {
    "system": "<持续时间最长的事件所属系统（monitor/gateway/logistics）>",
    "duration_minutes": <该事件时长（分钟）>
  }
}
```

**事件时长** = 末条故障时间 − 首条故障时间 + 1 分钟（同一条故障算 1 分钟；同一系统同一分钟的连续多条仍视为同一事件）。

## 提交形式

- 以字符串的形式提交给`submitAnswer`，例如：

```json
{"total_events":0,"avg_duration_minutes":0,"longest_event":{"system":"monitor","duration_minutes":0}}
```

- 提交答案为数字/字符串敏感型，不能将数字0写成"0"，否则算错
- `avg_duration_minutes` 是数字（如 5），不是小数

## 提示

- 日志格式与前两题完全相同，直接复用解析脚本
- 事件合并发生在**同一系统内**：三份日志要分开聚合，不能跨系统合并
- 建议把解析脚本封装为函数后只写一段事件合并逻辑（10 行以内）

````

